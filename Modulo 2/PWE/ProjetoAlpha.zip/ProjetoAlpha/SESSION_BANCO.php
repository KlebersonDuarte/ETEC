<?php
header("Content-Type: text/html; charset-utf-8");
//Testando sessões em php
if(isset($_REQUEST['valor']) and ($_REQUEST['valor'] == 'enviado')){
    //Cria sessão se usuário tiver clicado no botão enviar do formulário

    if($_POST['nome_banco'] == "" ||  $_POST['conta_banco'] == "" || $_POST['capital_banco'] == "" || $_POST['taxa_banco'] == "Selecione" || $_POST['tempo_banco'] == ""){
             echo "<script> alert('Preencha todos os campos!')</script>";
                     echo ("<meta http-equiv='refresh'content=0;'SESSION_BANCO.php'>");
        return;
    }

    session_start();

//Criar varíaveis de sessão que inicia junto com o formulário:
    $_SESSION['banco'] = $_POST['nome_banco'];
    $_SESSION['conta'] = $_POST['conta_banco'];
    $_SESSION['valor'] = $_POST['capital_banco'];
    $_SESSION['taxa'] = $_POST['taxa_banco'];
    $_SESSION['tempo'] = $_POST['tempo_banco'];

    $Capital = $_POST['capital_banco'];
    $Taxa = $_POST['taxa_banco'];

    $Taxa = ($Taxa/100) +1;
    $Tempo = $_POST['tempo_banco'];


    $Total = $Capital * (pow($Taxa,$Tempo));

    $_SESSION['rendimento'] = $Total;

    //exibe link para a página 03:
    echo "<a href='SESSION_PEDIDO.php'> Enviar dados !</a>";
}
else{
    //Se usuário ainda não clicou no botão de enviar,mostra o formulário na página:
        ?>

<form name= "form1" action="SESSION_BANCO.php?valor=enviado" method="POST">
    <p>Selecione seu Banco:<br>
    <select name="nome_banco" id="Banco">
        <option default value="Selecione">Selecione seu banco!</option>
        <option value="Banco do Brasil">Banco do Brasil</option>
        <option value="Banco caixa Econômica Federal">Caixa Econômica Federal</option>
        <option value="Banco Itaú">Banco Itaú</option>
        <option value="Banco Santander">Banco Santander</option>
    </select><br></p>
    <p>Digite sua Conta: <br> <input type="text" name="conta_banco"></br></p>
    <p>Digite o Capital (aplicado): <br> <input type="number" name="capital_banco"></p>
    <p>selecione a taxa (ao mês): <br>
        <select name="taxa_banco" id="Taxa"><br>

    <option  default value="Selecione">Selecione a taxa!</option>
    <option  value="0.50">0.50 %</option>
    <option value="0.75">0.75 %</option>
    <option value="1.00">1.00 %</option>
    <option value="1.50">1.50 %</option>
    <option value="1.75">1.75 %</option>
    <option value="2.00">2.00 %</option>
    <option value="2.50">2.50 %</option>
    <option value="2.75">2.75 %</option>
    <option value="3.00">3.00 %</option>
    <option value="3.50">3.50 %</option>
    <option value="3.75">3.75 %</option>
    <option value="4.00">4.00 5</option>
    <option value="4.50">4.50 %</option>
    <option value="4.75">4.75 %</option>
    <option value="5.00">5.00 %</option>
    </select><br></p>

    <p>
        Selecione o tempo(em meses): <br>
        <select name="tempo_banco" id="Tempo">
        <option default value="1">1 mês</option>
        <option value="2">2 meses</option>
        <option value="3">3 meses</option>
        <option value="4">4 meses</option>
        <option value="5">5 meses</option>
        <option value="6">6 meses</option>
        <option value="12">1 ano</option>
        <option value="24">2 anos</option>
        <option value="36">3 anos</option>
        <option value="48">4 anos</option>
        <option value="60">5 anos</option>
        </select> <br>
    </p><br>

    <input type="submit" value="Enviar">
</form>

        <?php
}

?>